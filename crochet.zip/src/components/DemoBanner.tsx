export default function DemoBanner() {
    return (
        <div className="bg-yellow-400 text-charcoal py-2 px-4 text-center text-xs font-bold uppercase tracking-widest z-[60] relative">
            ⚠️ This is a demo version. Payments, checkout and shipping are disabled.
        </div>
    );
}
